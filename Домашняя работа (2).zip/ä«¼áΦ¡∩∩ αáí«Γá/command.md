# *Удаленный репозиторий* #

**git clone** — создание копии (удаленного) репозитория. Например, *git clone http://user@somehost:port/~user/repository/project.git*

**git fetch и git pull** — забираем изменения из центрального репозитория. Например, *git remote add username-project /home/username/project*

**git push** — вносим изменения в удаленный репозиторий. Например, *git push ssh://yourserver.com/~you/proj.git master:experimental*

